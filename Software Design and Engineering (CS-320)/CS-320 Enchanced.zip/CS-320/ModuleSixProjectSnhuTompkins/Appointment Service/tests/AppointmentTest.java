package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import java.util.Date;
import java.util.Calendar;
import org.junit.jupiter.api.Test;

import service.Appointment;

class AppointmentTest {

//Ensures a good constructor for baseline
	@DisplayName("Test good constructor")
	@Test
	void testAppointment() {
        String id = "1";
        Calendar c = Calendar.getInstance();
        String description = "Good Description";
        
      	c.set(Calendar.MONTH, 11);
      	c.set(Calendar.DATE, 30);
      	c.set(Calendar.YEAR, 2026);
      	
      	Date goodDate = c.getTime();
        
        Appointment tempAppt = new Appointment(id, goodDate, description);
        
        assertEquals(1, tempAppt.getUniqueID());
        assertEquals(goodDate, tempAppt.getDate());
        assertEquals(description, tempAppt.getDescription());       
        
	}
	
//Changes good constructor and changes ID to be too long 
	@DisplayName("Test bad constructor id too long")
	@Test
	void testBadAppointment() {
        String id = "12345678910";
      	Date date = new Date();
        String description = "Good Description";
               
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, date, description);
        });
        
        assertEquals("Invalid ID", exception.getMessage());
        
	}
	//Test Null ID 
	@DisplayName("Test NULL ID")
	@Test
	void testBadIDNull() {
        String id = null;
      	Date date = new Date();
        String description = "Good Description";
               
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, date, description);
        });
        
        assertEquals("Invalid ID", exception.getMessage());
        
	}
	
	//Test if the date is in the past.
	@DisplayName("Test bad past date")
	@Test
	void testBadDate() {
        String id = "1";
        Calendar c = Calendar.getInstance();
      	String description = "Good Description";
      	
      	c.set(Calendar.MONTH, 11);
      	c.set(Calendar.DATE, 30);
      	c.set(Calendar.YEAR, 1996);
      	
      	Date badDate = c.getTime();
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, badDate, description);
        });
      	
      	assertEquals("Invalid date", exception.getMessage());
        
	}
	//Test if date is null
	@DisplayName("Test null date")
	@Test
	void testNullDate() {
        String id = "1";
      	String description = "Good Description";    	
      	Date badDate = null;
      	
      	Calendar c = Calendar.getInstance();
      	
      	c.set(Calendar.MONTH, 11);
      	c.set(Calendar.DATE, 30);
      	c.set(Calendar.YEAR, 2026);
      	
      	Date goodDate = c.getTime();
      	
      	Appointment tempAppt = new Appointment(id, goodDate, description);      	
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, badDate, description);
        });
      	
      	assertEquals("Invalid date", exception.getMessage());
      	
      	exception = assertThrows(IllegalArgumentException.class, () -> {
        	tempAppt.setDate(null);
        });
      	
      	assertEquals("Invalid date", exception.getMessage());
	}
	
	//Test when the description is too long
	@DisplayName("Test bad decription too long")
	@Test
	void testLongDesc() {
        String id = "1";
      	String description = "This ID is now over the maxium amount of character which should set off a fail. If not something is wrong.";    	
      	Calendar c = Calendar.getInstance();
      	
      	c.set(Calendar.MONTH, 11);
      	c.set(Calendar.DATE, 30);
      	c.set(Calendar.YEAR, 2026);
      	
      	Date goodDate = c.getTime();
      	
      	
      	Appointment tempAppt = new Appointment(id, goodDate, "test");
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, goodDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());
      	
      	exception = assertThrows(IllegalArgumentException.class, () -> {
        	tempAppt.setDescription(description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());
	}
	
	//Tests when the description is null
	@DisplayName("Test bad decription null")
	@Test
	void testNullDesc() {
        String id = "1";
      	String description = null;    	
      	Calendar c = Calendar.getInstance();
      	
      	c.set(Calendar.MONTH, 11);
      	c.set(Calendar.DATE, 30);
      	c.set(Calendar.YEAR, 2026);
      	
      	Date goodDate = c.getTime();
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, goodDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());
	}
	//Test when description is empty
	@DisplayName("Test bad decription empty")
	@Test
	void testEmptyDesc() {
        String id = "1";
      	String description = "";    	
      	Calendar c = Calendar.getInstance();
      	
      	c.set(Calendar.MONTH, 11);
      	c.set(Calendar.DATE, 30);
      	c.set(Calendar.YEAR, 2026);
      	
      	Date goodDate = c.getTime();
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, goodDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());
	}
	
}