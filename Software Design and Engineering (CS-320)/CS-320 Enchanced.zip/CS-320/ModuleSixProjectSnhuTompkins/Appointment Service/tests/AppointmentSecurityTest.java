package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;

import service.Appointment;
import service.AppointmentService;

class AppointmentSecurityTest {

	private Date futureDate() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, 10);
		return calendar.getTime();
	}

	@Test
	void dateAccessorsUseDefensiveCopies() {
		Date original = futureDate();
		Appointment appointment = new Appointment("1", original, "Description");
		long savedTime = appointment.getDate().getTime();

		original.setTime(0);
		Date returned = appointment.getDate();
		returned.setTime(0);

		assertEquals(savedTime, appointment.getDate().getTime());
	}

	@Test
	void invalidUpdateDoesNotPartiallyChangeAppointment() {
		AppointmentService service = new AppointmentService();
		Date original = futureDate();
		service.addUniqueAppointment(original, "Original");

		assertThrows(IllegalArgumentException.class,
				() -> service.updateAppointment("0", futureDate(), ""));
		assertEquals("Original", service.get("0").getDescription());
		assertEquals(original, service.get("0").getDate());
	}

	@Test
	void malformedIdsAreRejected() {
		AppointmentService service = new AppointmentService();
		assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(null));
		assertThrows(IllegalArgumentException.class,
				() -> service.updateAppointment("not-an-id", futureDate(), "Description"));
	}
}
