package service;

import java.util.Date;

public class Appointment {
		
	private final String uniqueID;
	private Date date;
	private String description;

	
	/**
	 * validates the uniqueID, not null, not greater than 10
	 * @param uniqueID
	 * @return bool
	 */
	private boolean validateID(String uniqueID) {
		return uniqueID != null && uniqueID.matches("\\d{1,10}");
	}
	
	/**
	 * validates the Date
	 * @param date
	 * @return bool
	 */
	private boolean validateDate(Date _date) {
		return _date != null && !_date.before(new Date());
	}
	/**
	 * validates the description, not null, not longer than 50, not a simlar desc. 
	 * @param date
	 * @return bool
	 */
	private boolean validateDescription(String description) {
		return description != null && !description.isBlank() && description.length() <= 50;
	}
	
	// validates variables
	public Appointment(String uniqueID, 
			Date date, 
			String description) {
		
		if(!this.validateID(uniqueID)) {
			throw new IllegalArgumentException("Invalid ID");
		}
		
		if(!this.validateDate(date)) {
			throw new IllegalArgumentException("Invalid date");
		}
		
		if(!this.validateDescription(description)) {
			throw new IllegalArgumentException("Invalid description");
		}		

		
		this.uniqueID = uniqueID;
		this.date = new Date(date.getTime());
		this.description = description;

	}

	public int getUniqueID() {
		return Integer.valueOf(uniqueID);
	}

	
	public Date getDate() {
		return new Date(date.getTime());
	}

	public void setDate(Date date) {
		if(!this.validateDate(date)) {
			throw new IllegalArgumentException("Invalid date");
		}
		this.date = new Date(date.getTime());
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		if(!this.validateDescription(description)) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.description = description;
	}
}