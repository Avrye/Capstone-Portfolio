package service;

import java.util.HashMap;
import java.util.Date;
import java.util.Collections;
import java.util.Map;

public class AppointmentService {
	
	private int currentIDNum;
	
	private final Map<String, Appointment> appointments = new HashMap<>();

	public int size() { return appointments.size(); }
	public boolean contains(String id) { return id != null && appointments.containsKey(id); }
	public Appointment get(String id) {
		Appointment appointment = appointments.get(id);
		return appointment == null ? null : new Appointment(Integer.toString(appointment.getUniqueID()),
				appointment.getDate(), appointment.getDescription());
	}
	public Map<String, Appointment> getAppointments() {
		Map<String, Appointment> snapshots = new HashMap<>();
		for (String id : appointments.keySet()) {
			snapshots.put(id, get(id));
		}
		return Collections.unmodifiableMap(snapshots);
	}
	
	public void addUniqueAppointment(Date _date, String _description) {

		String stringID = Integer.toString(currentIDNum);		
		Appointment tempAppointment = new Appointment (stringID, _date, _description);
		appointments.put(stringID, tempAppointment);	

		++currentIDNum;		
	}
	
	public void deleteAppointment(String unique_ID) {
		
		validateId(unique_ID);
		if(appointments.containsKey(unique_ID)) {
			appointments.remove(unique_ID);
		}		
	}
	
	//update of appointment
	  public void updateAppointment(String _ID, Date _date, String _newDescription)
	 {
	  
	  validateId(_ID);
	  Appointment appointment = appointments.get(_ID);
	  if (appointment != null) {
		  new Appointment(_ID, _date, _newDescription);
		  appointment.setDate(_date);
		  appointment.setDescription(_newDescription);
	  }
	 }

	private void validateId(String id) {
		if (id == null || !id.matches("\\d{1,10}")) {
			throw new IllegalArgumentException("Invalid ID");
		}
	}
	 
}