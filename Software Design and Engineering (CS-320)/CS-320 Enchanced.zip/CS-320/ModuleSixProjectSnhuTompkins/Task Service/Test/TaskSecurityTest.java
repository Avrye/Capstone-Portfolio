package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Task.TaskService;

class TaskSecurityTest {

	@Test
	void invalidUpdateDoesNotPartiallyChangeTask() {
		TaskService service = new TaskService();
		service.addUniqueTask("Task", "Original");

		assertThrows(IllegalArgumentException.class,
				() -> service.updateTasks("0", "Updated", ""));
		assertEquals("Task", service.get("0").getName());
		assertEquals("Original", service.get("0").getDescription());
	}

	@Test
	void malformedIdsAreRejected() {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class, () -> service.deleteTasks(null));
		assertThrows(IllegalArgumentException.class, () -> service.updateTasks("not-an-id", "Task", "Description"));
	}

	@Test
	void returnedTaskMapCannotMutateServiceStorage() {
		TaskService service = new TaskService();
		service.addUniqueTask("Task", "Description");

		assertThrows(UnsupportedOperationException.class, () -> service.getTasks().clear());
		assertEquals(1, service.size());
	}
}
