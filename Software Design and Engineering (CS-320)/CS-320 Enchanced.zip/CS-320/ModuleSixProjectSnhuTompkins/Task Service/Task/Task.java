package Task;

/**
 * Represents one task.
 */
public class Task {
	
	// Task ID assigned when the object is created.
	private final String uniqueID;
	// Task title.
	private String fullName;
	// Task details.
	private String description;

	// Checks whether the ID is valid.
	private boolean validateID(String uniqueID) {
		return uniqueID != null && uniqueID.matches("\\d{1,10}");
	}
	
	// Checks whether the name is valid.
	private boolean validateName(String fullName) {
		return fullName != null && !fullName.isBlank() && fullName.length() <= 20;
	}
	
	// Checks whether the description is valid.
	private boolean validateDescription(String description) {
		return description != null && !description.isBlank() && description.length() <= 50;
	}
	
	// Creates a task and validates all fields.
	public Task(String uniqueID, 
			String fullName, 
			String description) {
		
		if(!this.validateID(uniqueID)) {
			throw new IllegalArgumentException("Invalid ID");
		}
		
		if(!this.validateName(fullName)) {
			throw new IllegalArgumentException("Invalid name");
		}
		
		if(!this.validateDescription(description)) {
			throw new IllegalArgumentException("Invalid description");
		}		

		this.uniqueID = uniqueID;
		this.fullName = fullName;
		this.description = description;
	}

	// Returns the task ID as an integer.
	public int getUniqueID() {
		return Integer.valueOf(uniqueID);
	}

	// Returns the task name.
	public String getName() {
		return fullName;
	}

	// Updates the task name.
	public void setName(String fullName) {
		if(!this.validateName(fullName)) {
			throw new IllegalArgumentException("Invalid name");
		}
		this.fullName = fullName;
	}
	
	// Returns the task description.
	public String getDescription() {
		return description;
	}

	// Updates the task description.
	public void setDescription(String description) {
		if(!this.validateDescription(description)) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.description = description;
	}

	}
