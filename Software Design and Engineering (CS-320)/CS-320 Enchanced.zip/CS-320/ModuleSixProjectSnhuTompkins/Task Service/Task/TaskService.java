package Task;

import java.util.HashMap;
import java.util.Collections;
import java.util.Map;

/**
 * Stores and manages all tasks.
 */
public class TaskService {
	
	// Tracks the next task ID to assign.
	private int currentIDNum;
	
	// Holds tasks using their ID as the key.
	private final Map<String, Task> tasks = new HashMap<>();

	// Returns the number of tasks currently stored.
	public int size() { return tasks.size(); }
	
	// Checks whether a task exists for the given ID.
	public boolean contains(String id) { return id != null && tasks.containsKey(id); }
	
	// Returns a copy of the task with the given ID.
	public Task get(String id) {
		Task task = tasks.get(id);
		return task == null ? null : new Task(Integer.toString(task.getUniqueID()),
				task.getName(), task.getDescription());
	}
	
	// Returns all tasks as a read-only map.
	public Map<String, Task> getTasks() {
		Map<String, Task> snapshots = new HashMap<>();
		for (String id : tasks.keySet()) {
			snapshots.put(id, get(id));
		}
		return Collections.unmodifiableMap(snapshots);
	}
	
	// Adds a new task and assigns it the next available ID.
	public void addUniqueTask(String _name, String _description) {

		String stringID = Integer.toString(currentIDNum);		
		Task tempTask = new Task (stringID, _name, _description);
		tasks.put(stringID, tempTask);	

		++currentIDNum;		
	}
	
	// Deletes a task by ID if it exists.
	public void deleteTasks(String _ID) {
		
		validateId(_ID);
		if(tasks.containsKey(_ID)) {
			tasks.remove(_ID);
		}		
	}
	
	// Updates the name and description of an existing task.
	public void updateTasks(String _ID, String _newName, String _newDescription) {
		
		validateId(_ID);
		Task task = tasks.get(_ID);
		if(task != null) {
			new Task(_ID, _newName, _newDescription);
			task.setName(_newName);
			task.setDescription(_newDescription);
		}
		
	}

	// Ensures the ID is a valid numeric string.
	private void validateId(String id) {
		if (id == null || !id.matches("\\d{1,10}")) {
			throw new IllegalArgumentException("Invalid ID");
		}
	}
}