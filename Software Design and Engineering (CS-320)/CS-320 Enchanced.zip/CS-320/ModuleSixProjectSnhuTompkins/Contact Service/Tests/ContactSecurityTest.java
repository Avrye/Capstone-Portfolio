package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Contact.Contact;
import Contact.ContactService;

class ContactSecurityTest {

	@Test
	void rejectsMalformedAndBlankInput() {
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("abc", "Greg", "Hoffman", "1234567891", "123 Main Street"));
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("1", " ", "Hoffman", "1234567891", "123 Main Street"));
		assertThrows(IllegalArgumentException.class,
				() -> new Contact("1", "Greg", "Hoffman", "123-456-789", "123 Main Street"));
	}

	@Test
	void returnedContactListCannotMutateServiceStorage() {
		ContactService service = new ContactService();
		service.addContact("Greg", "Hoffman", "1234567891", "123 Main Street");

		assertThrows(UnsupportedOperationException.class, () -> service.getContacts().clear());
		assertEquals(1, service.size());
	}

	@Test
	void missingOrMalformedIdsAreRejected() {
		ContactService service = new ContactService();
		assertThrows(IllegalArgumentException.class, () -> service.deleteContact("abc"));
		assertThrows(IllegalArgumentException.class, () -> service.editAddress("99", "New Address"));
	}
}
