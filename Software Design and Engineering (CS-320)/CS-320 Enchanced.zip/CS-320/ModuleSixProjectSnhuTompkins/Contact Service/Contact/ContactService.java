package Contact;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



public class ContactService {
	
	private int currentIDNum;

	//create new arraylist to hold the objects
	private final List<Contact> contactList = new ArrayList<>();

	public int size() {
		return contactList.size();
	}

	public boolean contains(String id) {
		return id != null && contactList.stream().anyMatch(contact -> contact.getContactID() == parseId(id));
	}

	public Contact get(String id) {
		int contactId = parseId(id);
		return contactList.stream()
				.filter(contact -> contact.getContactID() == contactId)
				.findFirst()
				.map(contact -> new Contact(Integer.toString(contact.getContactID()),
						contact.getFirstName(), contact.getLastName(),
						contact.getPhoneNumber(), contact.getAddress()))
				.orElse(null);
	}

	public List<Contact> getContacts() {
		List<Contact> snapshots = new ArrayList<>();
		for (Contact contact : contactList) {
			snapshots.add(get(Integer.toString(contact.getContactID())));
		}
		return Collections.unmodifiableList(snapshots);
	}
	
	/**
	 * adds a contact at the system controlled index id
	 * @param firstName
	 * @param lastName
	 * @param phoneNumber
	 * @param address
	 */
	public void addContact(String firstName, String lastName,
			String phoneNumber, String address) {
		
		String stringID = Integer.toString(currentIDNum);
		
		Contact newContact = new Contact(stringID, firstName, lastName, phoneNumber, address);
		contactList.add(newContact);
		
		//increment the ID NUM
		++currentIDNum;

	}
	
	/**
	 * Deletes the contact as the index ID
	 * @param ID
	 */	
	public void deleteContact(String ID) {
		Contact contact = getRequired(ID);
		contactList.remove(contact);
	}
	
	/**
	 * Edits the First Name of the Contact Object at contactID
	 * Uses the setFirstName method
	 * @param contactID
	 * @param firstName
	 */
	public void editFirstName(String contactID, String firstName) {
		getRequired(contactID).setFirstName(firstName);
	}
	
	/**
	 * Edits the Lame Name of the Contact Object at contactID
	 * Uses the setLastName method
	 * @param contactID
	 * @param lastName
	 */
	public void editLastName(String contactID, String lastName) {
		getRequired(contactID).setLastName(lastName);
	}
	public void editNumber(String contactID, String phoneNumber) {
		getRequired(contactID).setPhoneNumber(phoneNumber);
	}
	public void editAddress(String contactID, String address) {
		getRequired(contactID).setAddress(address);
	}

	private Contact getRequired(String id) {
		int contactId = parseId(id);
		Contact contact = contactList.stream()
				.filter(candidate -> candidate.getContactID() == contactId)
				.findFirst().orElse(null);
		if (contact == null) {
			throw new IllegalArgumentException("Contact not found");
		}
		return contact;
	}

	private int parseId(String id) {
		if (id == null || !id.matches("\\d{1,10}")) {
			throw new IllegalArgumentException("Invalid contact ID");
		}
		return Integer.parseInt(id);
	}

}