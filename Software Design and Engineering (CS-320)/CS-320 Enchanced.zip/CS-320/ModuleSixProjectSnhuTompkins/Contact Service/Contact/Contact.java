package Contact;

public class Contact {
	
	private final String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;	
	
	/**
	 * 
	 * @param contactID
	 * @return bool
	 *contact cannot be null, and must be over 10 characters, and cant be changed
	 */
	private boolean validateID(String contactID) {
		return contactID != null && contactID.matches("\\d{1,10}");
	}
	
	/**
	 * last name cant be null or more than 10 characters
	 * @param lastName
	 * @return bool
	 */
	private boolean validateLastName(String lastName) {
		return lastName != null && !lastName.isBlank() && lastName.length() <= 10;
	}
	/**
	 * First name cant be null or more than 10 characters
	 * @param firstName
	 * @return bool
	 */
	private boolean validateFirstName(String firstName) {
		return firstName != null && !firstName.isBlank() && firstName.length() <= 10;
	}
	/**
	 * Phone Number cant be null and exactly 10 digits 
	 * @param phoneNumber
	 * @return bool
	 */
	private boolean validatePhone(String phoneNumber) {
		return phoneNumber != null && phoneNumber.matches("\\d{10}");
	}
	/**
	 *Address cant be more than 30 characters and cant be null
	 * @param address
	 * @return bool
	 */
	private boolean validateAddress(String address) {
		return address != null && !address.isBlank() && address.length() <= 30;
	}
	
	public Contact(String contactID, 
			String firstName, 
			String lastName, 
			String phoneNumber, 
			String address) {
		
		//Thrown erros
		if(!this.validateID(contactID)) {
			throw new IllegalArgumentException("Invalid contact ID");
		}
		
		if(!this.validateFirstName(firstName)) {
			throw new IllegalArgumentException("Invalid first name");
		}
		
		if(!this.validateLastName(lastName)) {
			throw new IllegalArgumentException("Invalid last name");
		}
		
		if(!this.validatePhone(phoneNumber)) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		
		if(!this.validateAddress(address)) {
			throw new IllegalArgumentException("Invalid address");
		}		
		
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}

	public int getContactID() {
		return Integer.valueOf(contactID);
	}


	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		if(!this.validateFirstName(firstName)) {
			throw new IllegalArgumentException("Invalid first name");
		}
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		if(!this.validateLastName(lastName)) {
			throw new IllegalArgumentException("Invalid last name");
		}
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		if(!this.validatePhone(phoneNumber)) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		if(!this.validateAddress(address)) {
			throw new IllegalArgumentException("Invalid address");
		}	
		this.address = address;
	}

}