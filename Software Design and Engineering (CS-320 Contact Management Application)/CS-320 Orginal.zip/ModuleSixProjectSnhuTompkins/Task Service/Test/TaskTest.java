package Test;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Task.Task;

class TaskTest {

	
	/**
	 * Invalid constructor with description too long
	 */
	@DisplayName("Invalid constructor")
	@Test
	void invalidContsructor() {
		
        String id = "1";
      	String fullName = "Lary Bob";
        String description = "This test should fail, This is because of the description being to many characters long so it should throw and error for this here.";
       
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Task(id, fullName, description);
        });		
	}
	
	/**
	 * Invalid constructor with long IDs
	 */
	@DisplayName("Invalid constructor with long ID")
	@Test
	void invalidIDConstruct() {
		
        String id = "0123456789101112";
      	String fullName = "Lary Bob";
        String description = "description";
       
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Task(id, fullName, description);
        });       
	}
	/**
	 * Invalid constructor with null IDs
	 */
	@DisplayName("Invalid constructor with long ID")
	@Test
	void invalidNullConstruct() {
		
        String id = null;
      	String fullName = "Lary Bob";
        String description = "description";
       
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Task(id, fullName, description);
        });       
	}
	
	/**
	 * Test the setFullName with good input 
	 */
	@DisplayName("Test a valid setName")
	@Test
	public void testGoodName() {
        String id = "1";
      	String fullName = "Lary Bob";
        String description = "Description";
		
        Task tempTask = new Task(id, fullName, description);  
        tempTask.setName("Test Name");        
        assertEquals("Test Name", tempTask.getName());
	}
	
	/**
	 * Test the setFullName with null input 
	 */
	@DisplayName("Test an invalid null setName")
	@Test
	public void testNullName() {
        String id = "1";
      	String fullName = "Lary Bob";
        String description = "description";
		
        Task tempTask = new Task(id, fullName, description);         
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            tempTask.setName(null); 
        });	
	}
	
	/**
	 * Test the setFullName with long input 
	 */
	@DisplayName("Test an invalid long setName")
	@Test
	public void testLongName() {
        String id = "1";
      	String fullName = "Lary Bob";
        String description = "Description";
		
        Task tempTask = new Task(id, fullName, description);         
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            tempTask.setName("I was gonna look up the longest name in the world but I think this comes close."); 
        });	
	}
	
	/**
	 * Test the setFullName with empty string 
	 */
	@DisplayName("Test an invalid empty setName")
	@Test
	public void testEmptyName() {
        String id = "1";
      	String fullName = "Lary Bob";
        String description = "This is a good description";
		
        Task tempTask = new Task(id, fullName, description);         
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            tempTask.setName(""); 
        });	
	}
	
	
	/**
	 * Test the setDescription with empty string 
	 */
	@DisplayName("Test an invalid empty description")
	@Test
	public void testEmptyDescription() {
        String id = "1";
      	String fullName = "Lary Bob";
        String description = "";                 
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Task(id, fullName, description);; 
        });	
	}
	
	/**
	 * Test the setDescription with null string 
	 */
	@DisplayName("Test a null description")
	@Test
	public void testNullDescription() {
        String id = "1";
      	String fullName = "Lary Bob";
        String description = null;                 
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Task(id, fullName, description);; 
        });	
	}
}	
