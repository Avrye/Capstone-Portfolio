package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import service.AppointmentService;
import org.junit.jupiter.api.DisplayName;

class AppointmentServiceTests {

	@AfterEach
	void tearDown() throws Exception {
		AppointmentService.appointments.clear();
	}
//Test for adding an appointment for base standard. 
	@DisplayName("Add an Appointment")
	@Test
	void testAddUniqueAppt() {
		String id = "0";
		String description = "Good Description";
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 11);
		c.set(Calendar.DATE, 30);
		c.set(Calendar.YEAR, 2026);

		Date goodDate = c.getTime();

		AppointmentService tempAppt = new AppointmentService();

		assertEquals(0, AppointmentService.appointments.size());

		tempAppt.addUniqueAppointment(goodDate, description);

		assertTrue(AppointmentService.appointments.containsKey(id));
		assertEquals(goodDate, AppointmentService.appointments.get(id).getDate());
		assertEquals(description, AppointmentService.appointments.get(id).getDescription());

	}
	
	//Edits good appointment and test a bad description
	
	@DisplayName("Add a bad Appointment w/ empty desc")
	@Test
	void testAddEmptyDesc() {
		String id = "0";
		String description = ""; //bad description
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 11);
		c.set(Calendar.DATE, 30);
		c.set(Calendar.YEAR, 2026);

		Date goodDate = c.getTime();

      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
      		AppointmentService tempAppt = new AppointmentService();
      		tempAppt.addUniqueAppointment(goodDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());

	}
	//Adds an appointment with a null description
	@DisplayName("Add a bad Appointment w/ null desc")
	@Test
	void testAddNullDesc() {
		String id = "0";
		String description = null; //bad description
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 11);
		c.set(Calendar.DATE, 30);
		c.set(Calendar.YEAR, 2026);

		Date goodDate = c.getTime();

      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
      		AppointmentService tempAppt = new AppointmentService();
      		tempAppt.addUniqueAppointment(goodDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());

	}

	/*
	 * Add 3 contacts via addAppt delete object at id 1 check that there is no
	 * object there
	 */
	@DisplayName("Test deleteAppt")
	@Test
	void testDeleteAppt() {

		String id = "0";
		String description = "Good Description";
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 11);
		c.set(Calendar.DATE, 30);
		c.set(Calendar.YEAR, 2026);

		Date goodDate = c.getTime();

		AppointmentService tempAppt = new AppointmentService();

		assertEquals(0, AppointmentService.appointments.size());

		tempAppt.addUniqueAppointment(goodDate, description); // object 0
		tempAppt.addUniqueAppointment(goodDate, description); // object 1
		tempAppt.addUniqueAppointment(goodDate, description); // object 2

		assertEquals(3, AppointmentService.appointments.size());

		tempAppt.deleteAppointment("1");

		assertEquals(2, AppointmentService.appointments.size());
		assertFalse(AppointmentService.appointments.containsKey("1"));
		
		tempAppt.deleteAppointment("1");
		assertEquals(2, AppointmentService.appointments.size());

	}

}