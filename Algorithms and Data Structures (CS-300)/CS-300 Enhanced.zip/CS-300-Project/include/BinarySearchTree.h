#pragma once

#include "Course.h"

#include <string>

// Binary search tree that stores Course records keyed by courseId.
class BinarySearchTree {
private:
    struct Node {
        Course course;
        Node* right;
        Node* left;

        // Default constructor for an empty node.
        Node();

        // Initialize a node with course data.
        explicit Node(Course aCourse);
    };

    Node* root;
    void inOrder(Node* node);
    int size;

public:
    BinarySearchTree();
    void InOrder();
    void Insert(Course aCourse);
    void Remove(std::string courseId);
    Course Search(std::string courseId);
    int Size();
};
