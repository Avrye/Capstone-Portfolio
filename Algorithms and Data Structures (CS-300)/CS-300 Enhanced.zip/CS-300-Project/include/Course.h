#pragma once

#include <string>
#include <vector>

// Course information for the academic catalog.
struct Course {
    std::string courseId;
    std::string courseName;
    std::vector<std::string> preList;
};
