#pragma once

#include <chrono>
#include <iostream>
#include <string>

// Display elapsed time for a completed operation in milliseconds.
inline void displayPerformance(std::string operation, std::chrono::steady_clock::time_point startTime) {
    const std::chrono::steady_clock::time_point endTime = std::chrono::steady_clock::now();
    const std::chrono::duration<double, std::milli> elapsedTime = endTime - startTime;
    std::cout << operation << " time: " << elapsedTime.count() << " ms" << std::endl;
}
