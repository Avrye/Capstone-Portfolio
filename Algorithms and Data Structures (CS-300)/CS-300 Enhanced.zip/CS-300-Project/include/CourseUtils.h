#pragma once

#include "BinarySearchTree.h"

#include <string>
#include <vector>

// Split a CSV row into its individual values while trimming whitespace.
std::vector<std::string> Split(std::string lineFeed);

// Load the course catalog from a CSV file into the provided BST.
void loadCourses(std::string csvPath, BinarySearchTree* courseList);

// Display a single course and its prerequisite list.
void displayCourse(Course aCourse);

// Convert all alphabetic characters in a string to uppercase.
void convertCase(std::string& toConvert);
