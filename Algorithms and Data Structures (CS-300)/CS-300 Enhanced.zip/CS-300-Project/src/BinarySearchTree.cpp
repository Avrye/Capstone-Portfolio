#include "BinarySearchTree.h"

#include <iostream>

using namespace std;

BinarySearchTree::Node::Node() : course(), right(nullptr), left(nullptr) {
}

BinarySearchTree::Node::Node(Course aCourse) : course(aCourse), right(nullptr), left(nullptr) {
}

// Initialize an empty tree and set the tracked item count to zero.
BinarySearchTree::BinarySearchTree() : root(nullptr), size(0) {
}

// Traverse the tree in sorted order and print each course.
void BinarySearchTree::InOrder() {
    inOrder(root);
}

// Insert a course into the BST while preserving sorted order.
void BinarySearchTree::Insert(Course aCourse) {
    if (root == nullptr) {
        root = new Node(aCourse);
        size++;
        return;
    }

    Node* currentNode = root;
    while (currentNode != nullptr) {
        if (aCourse.courseId == currentNode->course.courseId) {
            // Duplicate course IDs are ignored to keep the catalog consistent.
            return;
        }

        if (aCourse.courseId < currentNode->course.courseId) {
            if (currentNode->left == nullptr) {
                currentNode->left = new Node(aCourse);
                size++;
                return;
            }
            currentNode = currentNode->left;
        }
        else {
            if (currentNode->right == nullptr) {
                currentNode->right = new Node(aCourse);
                size++;
                return;
            }
            currentNode = currentNode->right;
        }
    }
}

// Remove a course record by its unique course ID.
void BinarySearchTree::Remove(string courseId) {
    Node* parent = nullptr;
    Node* currentNode = root;

    while (currentNode != nullptr && currentNode->course.courseId != courseId) {
        parent = currentNode;
        if (courseId < currentNode->course.courseId) {
            currentNode = currentNode->left;
        }
        else {
            currentNode = currentNode->right;
        }
    }

    if (currentNode == nullptr) {
        cout << "\nValue not found" << endl;
        return;
    }

    if (currentNode->left == nullptr && currentNode->right == nullptr) {
        if (parent == nullptr) {
            root = nullptr;
        }
        else if (parent->left == currentNode) {
            parent->left = nullptr;
        }
        else {
            parent->right = nullptr;
        }
    }
    else if (currentNode->left == nullptr) {
        Node* replacement = currentNode->right;
        if (parent == nullptr) {
            root = replacement;
        }
        else if (parent->left == currentNode) {
            parent->left = replacement;
        }
        else {
            parent->right = replacement;
        }
    }
    else if (currentNode->right == nullptr) {
        Node* replacement = currentNode->left;
        if (parent == nullptr) {
            root = replacement;
        }
        else if (parent->left == currentNode) {
            parent->left = replacement;
        }
        else {
            parent->right = replacement;
        }
    }
    else {
        Node* successorParent = currentNode;
        Node* successor = currentNode->right;

        while (successor->left != nullptr) {
            successorParent = successor;
            successor = successor->left;
        }

        currentNode->course = successor->course;

        if (successorParent->left == successor) {
            successorParent->left = successor->right;
        }
        else {
            successorParent->right = successor->right;
        }

        delete successor;
    }

    size--;
}

// Find a course by course ID and return the full record when found.
Course BinarySearchTree::Search(string courseId) {
    Course emptyCourse;
    Node* currentNode = root;

    while (currentNode != nullptr) {
        if (currentNode->course.courseId == courseId) {
            return currentNode->course;
        }
        else if (courseId < currentNode->course.courseId) {
            currentNode = currentNode->left;
        }
        else {
            currentNode = currentNode->right;
        }
    }

    return emptyCourse;
}

void BinarySearchTree::inOrder(Node* node) {
    if (node == nullptr) {
        return;
    }

    inOrder(node->left);
    cout << node->course.courseId << ", " << node->course.courseName << endl;
    inOrder(node->right);
}

int BinarySearchTree::Size() {
    return size;
}
