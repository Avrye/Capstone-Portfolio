// CS-300 Final Project, 10/14/2025

#include "BinarySearchTree.h"
#include "CourseUtils.h"
#include "Performance.h"

#include <cstdlib>
#include <iostream>
#include <limits>
#include <string>
#include <Windows.h>

using namespace std;

const int GLOBAL_SLEEP_TIME = 5000; // Delay used between menu actions.

int main(int argc, char* argv[]) {
    // Process optional command-line arguments.
    string csvPath = "FinalProject_Sample_input.csv";
    string aCourseKey;

    if (argc >= 2) {
        csvPath = argv[1];
    }

    if (argc >= 3) {
        aCourseKey = argv[2];
    }

    // Keep the course catalog on the stack so it is automatically cleaned up.
    BinarySearchTree courseList;
    Course course;
    int choice = 0;

    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Courses" << endl;
        cout << "  2. Display All Courses in alphabetical order" << endl;
        cout << "  3. Find Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";

        aCourseKey = "";
        string anyKey = " ";

        if (!(cin >> choice)) {
            cout << "\nPlease check your input." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            Sleep(GLOBAL_SLEEP_TIME);
            system("cls");
            continue;
        }

        switch (choice) {
        case 1: {
            // Start the clock before loading the file.
            const chrono::steady_clock::time_point loadStart = chrono::steady_clock::now();
            loadCourses(csvPath, &courseList);
            cout << courseList.Size() << " courses read" << endl;
            displayPerformance("Load", loadStart);
            Sleep(GLOBAL_SLEEP_TIME);
            break;
        }
        case 2: {
            if (courseList.Size() == 0) {
                cout << "\nNo courses are loaded yet. Please choose option 1 first." << endl;
                Sleep(GLOBAL_SLEEP_TIME);
                break;
            }

            // Start the clock before printing the sorted course list.
            const chrono::steady_clock::time_point displayStart = chrono::steady_clock::now();
            courseList.InOrder();
            displayPerformance("Sorted display", displayStart);

            cout << "\nEnter 'y' to continue..." << endl;
            cin >> anyKey;
            break;
        }
        case 3: {
            if (courseList.Size() == 0) {
                cout << "\nNo courses are loaded yet. Please choose option 1 first." << endl;
                Sleep(GLOBAL_SLEEP_TIME);
                break;
            }

            cout << "\nWhat course do you want to know about? " << endl;
            cin >> aCourseKey;
            convertCase(aCourseKey);

            // Start the clock before searching the tree.
            const chrono::steady_clock::time_point searchStart = chrono::steady_clock::now();
            course = courseList.Search(aCourseKey);
            displayPerformance("Search", searchStart);

            if (!course.courseId.empty()) {
                displayCourse(course);
            }
            else {
                cout << "\nCourse ID " << aCourseKey << " not found." << endl;
            }
            Sleep(GLOBAL_SLEEP_TIME);
            break;
        }
        case 9:
            break;
        default:
            cout << "\nPlease check your input." << endl;
            Sleep(GLOBAL_SLEEP_TIME);
            break;
        }

        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        // Clear the screen before returning to the menu.
        system("cls");
    }

    cout << "Good bye." << endl;
    Sleep(GLOBAL_SLEEP_TIME);
    return 0;
}
