#include "CourseUtils.h"

#include <cctype>
#include <fstream>
#include <iostream>

using namespace std;

namespace {
// Remove leading and trailing whitespace from a CSV field.
std::string trimString(const std::string& value) {
    const size_t first = value.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) {
        return "";
    }

    const size_t last = value.find_last_not_of(" \t\r\n");
    return value.substr(first, last - first + 1);
}
}

// Split a CSV row into individual values and trim spaces around each entry.
vector<string> Split(string lineFeed) {
    vector<string> lineTokens;
    string temp;

    for (char character : lineFeed) {
        if (character == ',') {
            lineTokens.push_back(trimString(temp));
            temp.clear();
        }
        else {
            temp += character;
        }
    }

    lineTokens.push_back(trimString(temp));
    return lineTokens;
}

// Read each CSV record and insert it into the catalog tree.
void loadCourses(string csvPath, BinarySearchTree* courseList) {
    if (courseList == nullptr) {
        cout << "Course list is not initialized." << endl;
        return;
    }

    ifstream inFS(csvPath);
    if (!inFS.is_open()) {
        cout << "Could not open file. Please check inputs." << endl;
        return;
    }

    string line;
    while (getline(inFS, line)) {
        if (line.empty()) {
            continue;
        }

        vector<string> stringTokens = Split(line);
        if (stringTokens.size() < 2) {
            cout << "\nError. Skipping line." << endl;
            continue;
        }

        Course aCourse;
        aCourse.courseId = trimString(stringTokens.at(0));
        aCourse.courseName = trimString(stringTokens.at(1));

        if (aCourse.courseId.empty() || aCourse.courseName.empty()) {
            continue;
        }

        convertCase(aCourse.courseId);

        for (size_t i = 2; i < stringTokens.size(); ++i) {
            string prerequisite = trimString(stringTokens.at(i));
            if (!prerequisite.empty()) {
                convertCase(prerequisite);
                aCourse.preList.push_back(prerequisite);
            }
        }

        courseList->Insert(aCourse);
    }

    inFS.close();
}

// Display the course ID, title, and any prerequisites.
void displayCourse(Course aCourse) {
    cout << aCourse.courseId << ", " << aCourse.courseName << endl;
    cout << "Prerequisites: ";

    if (aCourse.preList.empty()) {
        cout << "none" << endl;
    }
    else {
        for (size_t i = 0; i < aCourse.preList.size(); ++i) {
            cout << aCourse.preList.at(i);
            if (aCourse.preList.size() > 1 && i < aCourse.preList.size() - 1) {
                cout << ", ";
            }
        }
        cout << endl;
    }
}

// Convert the provided string to uppercase to keep course IDs consistent.
void convertCase(string& toConvert) {
    for (char& character : toConvert) {
        if (isalpha(static_cast<unsigned char>(character))) {
            character = static_cast<char>(toupper(static_cast<unsigned char>(character)));
        }
    }
}
