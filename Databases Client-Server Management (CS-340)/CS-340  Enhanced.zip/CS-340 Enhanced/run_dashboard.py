import base64
from pathlib import Path

import dash_leaflet as dl
import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, dash_table, html

from CRUD import AnimalShelter

###########################
# Data Manipulation / Model
###########################
# Load the animal records from MongoDB and remove the internal MongoDB identifier.
username = "aacuser"
password = "SNHU1234"

db = AnimalShelter(username, password)
df = pd.DataFrame.from_records(db.read({}))
df.drop(columns=["_id"], inplace=True, errors="ignore")

#########################
# Dashboard Layout / View
#########################
app = Dash(__name__)

# Encode the organization logo so it can be embedded directly in the dashboard.
image_path = Path(__file__).with_name("Grazioso Salvare Logo.png")
encoded_image = base64.b64encode(image_path.read_bytes()).decode("utf-8")

# Define the page header, rescue filters, animal table, and visualization containers.
app.layout = html.Div([
    html.Center(html.Img(src=f"data:image/png;base64,{encoded_image}", style={"width": "300px"})),
    html.Center(html.B(html.H1("CS-340 Dashboard"))),
    html.Center(html.B(html.H2("Developed by: Avrye Tompkins"))),
    html.Hr(),
    html.Div([
        dcc.RadioItems(
            id="filter-type",
            options=[
                {"label": "Water Rescue", "value": "Water Rescue"},
                {"label": "Mountain or Snowy Rescue", "value": "Mountain or Snowy Rescue"},
                {"label": "Disaster or Individual Tracking", "value": "Disaster or Individual Tracking"},
                {"label": "Reset", "value": "Reset"},
            ],
            value="Reset",
            labelStyle={"display": "inline-block", "margin-right": "10px"},
        )
    ], style={"padding": "10px"}),
    html.Hr(),
    dash_table.DataTable(
        id="datatable-id",
        columns=[{"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns],
        data=df.to_dict("records"),
        page_size=10,
        sort_action="native",
        filter_action="native",
        row_selectable="single",
        selected_rows=[0],
    ),
    html.Br(),
    html.Hr(),
    html.Div(className="row", style={"display": "flex"}, children=[
        html.Div(id="graph-id", className="col s12 m6", style={"flex": "1"}),
        html.Div(id="map-id", className="col s12 m6", style={"flex": "1"}),
    ]),
])

#############################################
# Interaction Between Components / Controller
#############################################
# Filter the animal table by the breed groups used for each rescue category.
@app.callback(Output("datatable-id", "data"), Input("filter-type", "value"))
def update_dashboard(filter_type):
    if filter_type == "Water Rescue":
        dff = df[(df["animal_type"] == "Dog") & (df["breed"].isin(["Labrador Retriever Mix", "Chesa Bay Retr Mix", "Newfoundland Mix"]))]
    elif filter_type == "Mountain or Snowy Rescue":
        dff = df[(df["animal_type"] == "Dog") & (df["breed"].isin(["Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler", "German Shepherd"]))]
    elif filter_type == "Disaster or Individual Tracking":
        dff = df[(df["animal_type"] == "Dog") & (df["breed"].isin(["Doberman Pinsch", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]))]
    else:
        dff = df
    return dff.to_dict("records")


# Build a breed distribution chart from the table's currently displayed rows.
@app.callback(Output("graph-id", "children"), Input("datatable-id", "derived_virtual_data"))
def update_graphs(viewData):
    if viewData is None or len(viewData) == 0:
        return []
    dff = pd.DataFrame.from_dict(viewData)
    return [dcc.Graph(figure=px.pie(dff, names="breed", title="Preferred Animals"))]


# Center the map on the selected row and show that animal's name and breed.
@app.callback(
    Output("map-id", "children"),
    Input("datatable-id", "derived_virtual_data"),
    Input("datatable-id", "derived_virtual_selected_rows"),
)
def update_map(viewData, index):
    if viewData is None or not index:
        return []

    dff = pd.DataFrame.from_dict(viewData)
    if "location_lat" not in dff.columns or "location_long" not in dff.columns:
        return []

    # Read values by field name so the map does not depend on table column order.
    row = index[0]
    row_data = dff.iloc[row]
    lat = row_data["location_lat"]
    lon = row_data["location_long"]
    animal_name = row_data.get("name", "Unknown")
    breed = row_data.get("breed", "Unknown")

    return [
        dl.Map(
            style={"width": "100%", "height": "500px"},
            center=[lat, lon],
            zoom=10,
            children=[
                dl.TileLayer(id="base-layer-id"),
                dl.Marker(
                    position=[lat, lon],
                    children=[
                        dl.Tooltip(f"{animal_name} ({breed})"),
                        dl.Popup([
                            html.H4("Animal Name"),
                            html.P(animal_name),
                            html.P(f"Breed: {breed}"),
                        ]),
                    ],
                ),
            ],
        )
    ]


# Start the local development server when this file is run directly.
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8050, debug=False)
