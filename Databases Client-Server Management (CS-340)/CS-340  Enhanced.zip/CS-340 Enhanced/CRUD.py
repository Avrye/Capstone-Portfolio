from collections.abc import Mapping
import math
from numbers import Real
from urllib.parse import quote_plus

from pymongo import ASCENDING, MongoClient


STRING_FIELDS = {
    "animal_id",
    "animal_type",
    "breed",
    "color",
    "date_of_birth",
    "datetime",
    "monthyear",
    "name",
    "outcome_subtype",
    "outcome_type",
    "sex_upon_outcome",
    "age_upon_outcome",
}
NUMERIC_FIELDS = {
    "location_lat",
    "location_long",
    "age_upon_outcome_in_weeks",
}
ANIMAL_FIELDS = STRING_FIELDS | NUMERIC_FIELDS
REQUIRED_FIELDS = {"animal_id", "animal_type", "breed"}

ANIMAL_VALIDATOR = {
    "$jsonSchema": {
        "bsonType": "object",
        "required": sorted(REQUIRED_FIELDS),
        "additionalProperties": False,
        "properties": {
            "_id": {"bsonType": "objectId"},
            **{
                field: {"bsonType": ["string", "null"]}
                for field in sorted(STRING_FIELDS)
            },
            **{
                field: {
                    "bsonType": ["double", "int", "long", "decimal", "null"]
                }
                for field in sorted(NUMERIC_FIELDS)
            },
        },
    }
}


class AnimalShelter:
    def __init__(self, username, password):
        uri = (
            f"mongodb://{quote_plus(username)}:{quote_plus(password)}"
            "@localhost:27017/?authSource=admin"
        )
        self.client = MongoClient(uri)
        self.database = self.client["AAC"]

        if "animals" not in self.database.list_collection_names():
            self.database.create_collection(
                "animals",
                validator=ANIMAL_VALIDATOR,
                validationLevel="strict",
                validationAction="error",
            )
        else:
            self.database.command(
                {
                    "collMod": "animals",
                    "validator": ANIMAL_VALIDATOR,
                    "validationLevel": "strict",
                    "validationAction": "error",
                }
            )

        self.collection = self.database["animals"]
        self.collection.create_index(
            [("animal_type", ASCENDING), ("breed", ASCENDING)],
            name="animal_type_breed_idx",
        )
        self.collection.create_index(
            [("animal_id", ASCENDING)],
            name="animal_id_idx",
        )

    @staticmethod
    def _validate_value(field, value):
        if value is None:
            return
        if field in STRING_FIELDS:
            if not isinstance(value, str):
                raise ValueError(f"{field} must be a string or None")
            return
        if isinstance(value, bool) or not isinstance(value, Real):
            raise ValueError(f"{field} must be a finite number or None")
        if not math.isfinite(value):
            raise ValueError(f"{field} must be a finite number or None")

    @classmethod
    def _validate_document(cls, document, require_required=False):
        if not isinstance(document, Mapping):
            raise ValueError("Document must be a mapping")

        result = dict(document)
        for field, value in result.items():
            if not isinstance(field, str) or field not in ANIMAL_FIELDS:
                raise ValueError(f"Unsupported animal field: {field!r}")
            cls._validate_value(field, value)

        if require_required:
            missing = REQUIRED_FIELDS - result.keys()
            if missing:
                raise ValueError(
                    f"Missing required animal fields: {', '.join(sorted(missing))}"
                )
            for field in REQUIRED_FIELDS:
                if not result[field]:
                    raise ValueError(f"{field} must be a non-empty string")

        return result

    @classmethod
    def _validate_query(cls, query, allow_empty=True):
        if not isinstance(query, Mapping):
            raise ValueError("Query must be a mapping")
        if not allow_empty and not query:
            raise ValueError("Query must not be empty")

        result = dict(query)
        for field, value in result.items():
            if not isinstance(field, str) or field not in ANIMAL_FIELDS:
                raise ValueError(f"Unsupported query field: {field!r}")
            cls._validate_value(field, value)
        return result

    def create(self, data):
        document = self._validate_document(data, require_required=True)
        result = self.collection.insert_one(document)
        return result.acknowledged

    def read(self, searchData):
        query = self._validate_query(searchData)
        return list(self.collection.find(query, {"_id": False}))

    def update(self, query, newValue):
        safe_query = self._validate_query(query, allow_empty=False)
        update = self._validate_document(newValue)
        if not update:
            raise ValueError("Update document must not be empty")

        result = self.collection.update_many(safe_query, {"$set": update})
        self.records_updated = result.modified_count
        self.records_matched = result.matched_count
        return result.modified_count > 0

    def delete(self, query):
        safe_query = self._validate_query(query, allow_empty=False)
        result = self.collection.delete_many(safe_query)
        self.records_deleted = result.deleted_count
        return result.deleted_count > 0
