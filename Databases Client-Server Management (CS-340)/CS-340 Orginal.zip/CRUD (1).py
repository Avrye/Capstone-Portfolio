
from pymongo import MongoClient 
from bson.objectid import ObjectId 
import urllib.parse

#initilizing connection to the mongosh database
class AnimalShelter(object):
    def __init__(self, username, password):
            self.client = MongoClient('mongodb://%s:%s@localhost:27017/?authSource=admin' % (username, password))
            self.database = self.client['AAC']
            self.collection = self.database['animals']
        

            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None: 
            self.database.animals.insert_one(data)  # data should be dictionary             
            if insertSuccess != 0: #success check
                return False
            #Default return 
            return True
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 

    # Create method to implement the R in CRUD.
    def read(self, searchData):
        if searchData:
            data = self.database.animals.find(searchData, {"_id": False})
        else:
            data = self.database.animals.find( {}, {"_id": False})
                
            #Return data set if no catch
            return data
        
    #Create method to implemetn the U in CRUD
    
    def update(self, query, newValue):
        if not query:
            raise Exception("No search is present")
        elif not newValue:
            raise Exception("No update is avaible")
        else: 
            updateValid = self.dataBase.animals.update_many(query, {"$set": newValue})
            self.records_updated = updateValid.modified_cound
            self.recods_matched = updateValid.matched
        return True if updateValid.modified > 0 else False
        
        #Create metodto implement the D in CRUD
        
    def delete(self, query):
        if not query:
                raise Exception("No search is present.")#if search is invalid
        else:
                delete = self.dataBase.animals.delete(query)#delete if valid
                self.records_deleted = deleteValid.deleted 
                
        return True if deleteValid.deleted_count > 0 else False
        